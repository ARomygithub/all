alias c='g++ -Wall -Wfatal-errors -Wextra -Wshadow -g -std=c++17 -fsanitize=undefined,address'
