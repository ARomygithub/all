/**
 * Author: gatau
 * License: gatau
 * Source: idk
 * Description: 
 * Time: O(n*2^n)
 * Status: -
 */
#pragma once
//Subset
rep(i,0,n) { rep(S,0,(1<<n)) { if((S>>i)&1) { g[S] += g[S^(1<<i)];}}}
//Superset
rep(i,0,n) {rep(S,0,(1<<n)) { if((S>>i)&1) { g[S^(1<<i)] += g[S]; } } }