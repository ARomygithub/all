/**
 * Author: chilli, Andrew He, Adamant
 * Date: 2019-04-27
 * Description: A FFT based Polynomial class.
 */
#pragma once

#include "PolyBase.h"
#include "PolyLogExp.h"

poly shift(poly a, ll x) {
	poly res(sz(a));
	rep(i,0,sz(a)) {
		if(i-x>=0 && i-x<sz(a)) {
			res[i] = a[i-x];
		}
	}
	return res;
}

poly pow(poly a, ll m) {
	if(m==0) {
		fill(all(a), 0);
		a[0] = 1;
		return a;
	}
	int p = 0, n = sz(a);
	while (p < sz(a) && a[p].x == 0)
		++p;
	if(p==n) return a;
	if (p >= (n + m-1)/m) return poly(sz(a));
	num j = a[p];
	a = {a.begin() + p, a.end()};
	a = a * (num(1) / j);
	a.resize(n);
	auto res =  exp(log(a) * num(m)) * (j ^ m);
	res = shift(res, p*m);
	return {res.begin(), res.begin()+n};
}
