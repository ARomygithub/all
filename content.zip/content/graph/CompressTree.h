/**
 * Author: Simon Lindholm
 * Date: 2016-01-14
 * License: CC0
 * Description: Given a rooted tree and a subset S of nodes, compute the minimal
 * subtree that contains all the nodes by adding all (at most $|S|-1$)
 * pairwise LCA's and compressing edges.
 * Returns a list of (par, orig\_index) representing a tree rooted at 0.
 * The root points to itself. OR AUXILIARY TREE
 * Time: $O(|S| \log |S|)$
 * Status: Tested at CodeForces
 */
#pragma once

#include "LCA.h"

typedef vector<pair<int, int>> vpi;
vpi compressTree(LCA& lca, const vi& subset) {
	static vi rev; rev.resize(sz(lca.time));
	vi li = subset, &T = lca.time;
	auto cmp = [&](int a, int b) { return T[a] < T[b]; };
	sort(all(li), cmp);
	int m = sz(li)-1;
	rep(i,0,m) {
		int a = li[i], b = li[i+1];
		li.push_back(lca.lca(a, b));
	}
	sort(all(li), cmp);
	li.erase(unique(all(li)), li.end());
	rep(i,0,sz(li)) rev[li[i]] = i;
	vpi ret = {pii(0, li[0])};
	rep(i,0,sz(li)-1) {
		int a = li[i], b = li[i+1];
		ret.emplace_back(rev[lca.lca(a, b)], b);
	}
	return ret;
}
auto solve_aux = [&](int ci) -> void {
	vector<pii> vec = mpvec[ci];
	set<pii> aux;
	sort(vec.begin(),vec.end());
	rep(i,0,sz(vec)) {
		aux.insert(vec[i]);
		if(i+1<sz(vec)) {
			int u = lca.lca(vec[i].se,vec[i+1].se);
			aux.insert({lca.time[u], u});
		}
	}
	stack<int> st;
	for(auto [ti, u]: aux) {
		if(sz(st)) {
			while(lca.lca(st.top(), u) != st.top()) {
				st.pop();
			}
			adj2[st.top()].push_back(u);
			st.push(u);
		} else {
			st.push(u);
		}
	}
	int r = (*aux.begin()).se;
	/* DFS */
	for(auto [ti,u]: aux) {
		adj2[u].clear();
	}	
}